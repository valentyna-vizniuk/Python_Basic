import Students

st1 = Students.Student('Male', 30, 'Steve', 'Jobs', 'AN142')
st2 = Students.Student('Female', 25, 'Liza', 'Taylor', 'AN145')
gr = Students.Group('PD1')
gr.add_student(st1)
gr.add_student(st2)
print(gr)

assert gr.find_student('Jobs') == st1, 'Test1'
assert gr.find_student('Jobs2') is None

print(st1 == st2)

gr.delete_student('Taylor')
print(gr) # Only one student

print(st1 == st2)